# ResQ frontend

A responsive frontend for the uploaded Emergency Resource Allocation System C++ project.

## Preview
Open `index.html`, or use VS Code Live Server. Alternatively, run `python -m http.server 5500` in this folder and visit `http://localhost:5500`.

If the C++ API is unavailable, the page clearly shows **DEMO MODE** and uses temporary sample data. Demo changes are only in the browser; they are NOT saved to your C++ text files.

## C++ integration status
Your uploaded source is currently a console application: it uses `cin`/`cout` and has no HTTP server. Therefore this frontend is prepared for a REST API but is not connected to the C++ executable yet. The next step is to add an HTTP server and JSON endpoints to the C++ project, reusing its existing `Graph`, `EmergencyManager`, and `ResourceManager`.

## Expected REST API (JSON)
All endpoints are under `/api` on the same host:
- `GET /emergencies` -> `{ "emergencies": [{ "id":1,"victimName":"A","location":"College","priority":3,"requiredType":"Ambulance" }] }`
- `POST /emergencies` body `{ "victimName":"A","location":"College","priority":3,"requiredType":"Ambulance" }`
- `GET /resources` -> `{ "resources": [{ "id":1,"name":"Ambulance 1","type":"Ambulance","location":"Hospital","available":true }] }`
- `POST /resources` body `{ "name":"Ambulance 1","type":"Ambulance","location":"Hospital" }`
- `POST /release` body `{ "id":1 }`
- `GET /locations` -> `{ "locations":["Hospital","College"] }`
- `POST /locations` body `{ "name":"Hospital" }`
- `GET /roads` -> `{ "roads":[{"source":"Hospital","destination":"College","distance":5}] }`
- `POST /roads` body `{ "source":"Hospital","destination":"College","distance":5 }`
- `GET /routes?source=College` -> `{ "routes":[{"destination":"Hospital","distance":8}] }`
- `POST /allocate` body `{}` -> `{ "emergency":{...},"resource":{...},"distance":4,"route":["College","Railway Station"] }`

On errors, return a non-2xx HTTP status and JSON `{ "error":"Helpful message" }`.
